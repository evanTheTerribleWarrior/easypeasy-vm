import React from "react";
import "./Contact.css"

function Contact() {
  return (
    <div className="contact">
      <div class="container">
        <div class="row align-items-center my-5">
          <div class="col-lg-7">
            <div class="card">
              <div class="card-body">
                <img src="ceo.jpeg" className="photo" />
                <p>
              John, our CEO. His mission is to help you achieve your goals. Besides that, he loves swimming and cycling
            </p>
              </div>
            </div>
            <div class="card">
              <div class="card-body">
                <img src="norman.jpeg" className="photo"/>
                <p>
              Norman, our IT genius. He has more than 20 years of experience - he set up our infrastructure from scratch! You want Samba? FTP? Website? He is your man! Oh, and side note. He LOVES his dog, "isabel"
            </p>
              </div>
            </div>
            <div class="card">
              <div class="card-body">
                <img src="brenda.jpeg" className="photo"/>
                <p>
              Brenda, our Software Developer. She can code a whole new world in dt time!
            </p>
              </div>
            </div>
          </div>
          <div class="col-lg-5">
            <h1 class="font-weight-light">Contact</h1>
            <p>
              Our amazing team is here to assist you. Please contact us. @john, @norman, @brenda
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Contact;
