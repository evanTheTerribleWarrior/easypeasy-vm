<?php
//This is the old default theme of pluck
//Designer: Sander Thijsen, http://www.somp.nl
//You can find pluck at http://www.pluck-cms.org

$themedir = "oldstyle";
$themename = "Oldstyle";
$module_space[0] = "main";
$module_space[1] = "footer";
?>