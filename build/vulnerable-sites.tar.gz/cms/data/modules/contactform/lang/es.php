<?php
$lang['contactform']['module_name'] = 'formulario de contacto';
$lang['contactform']['module_intro'] = 'a través de un formulario de contacto, tus visitantes pueden mandarte un mensaje';
$lang['contactform']['fields'] = 'No has rellenado correctamente todos los campos.';
$lang['contactform']['email_title'] = 'Mensaje desde tu sitio web de';
$lang['contactform']['been_send'] = 'Mensaje enviado correctamente.';
$lang['contactform']['not_send'] = 'Ha ocurrido un error, el mensaje no se puede enviar.';
?>