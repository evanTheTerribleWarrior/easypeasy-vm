<?php
$lang['contactform']['module_name'] = 'Formulário para Contato';
$lang['contactform']['module_intro'] = 'com o formulário para contato, seus visitantes podem lhe enviar mensagens';
$lang['contactform']['fields'] = 'Você não preencheu todos os campos corretamente.';
$lang['contactform']['email_title'] = 'Mensagem vinda do formulário de email de';
$lang['contactform']['been_send'] = 'Sua mensagem foi enviada.';
$lang['contactform']['not_send'] = 'Sua mensagem não pode sem enviada, ocorreu um erro.';
?>