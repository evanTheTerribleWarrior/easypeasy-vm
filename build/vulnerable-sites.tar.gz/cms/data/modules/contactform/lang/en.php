<?php
$lang['contactform']['module_name']  = 'contact form';
$lang['contactform']['module_intro'] = 'with a contact form, you can allow your visitors to send you a message';
$lang['contactform']['fields']       = 'You didn\'t fill in all fields correctly.';
$lang['contactform']['email_title']  = 'Message from your website from';
$lang['contactform']['been_send']    = 'Your message has been sent succesfully.';
$lang['contactform']['not_send']     = 'Your message could not be sent, an error occurred.';
?>