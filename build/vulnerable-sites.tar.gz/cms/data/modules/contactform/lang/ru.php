<?php
$lang['contactform']['module_name'] = 'contact form';
$lang['contactform']['module_intro'] = 'with a contact form, you can allow your visitors to send you a message';
$lang['contactform']['fields'] = 'Вы заполнили не все поля правильно.';
$lang['contactform']['email_title'] = 'Сообщение с Вашего сайта от';
$lang['contactform']['been_send'] = 'Сообщение успешно отправлено';
$lang['contactform']['not_send'] = 'Сообщение не может быть отправлено, произошла ошибка.';
?>