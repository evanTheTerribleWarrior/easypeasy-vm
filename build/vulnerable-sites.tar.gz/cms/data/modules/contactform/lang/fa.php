<?php
$lang['contactform']['module_name'] = 'فرم ارتباط';
$lang['contactform']['module_intro'] = 'با فرم ارتباط ، شما می توانید با کاربرانتان ارتباط راحت برقرار کنید.';
$lang['contactform']['fields'] = 'تمام بخش ها را صحیح وارد نکرده اید.';
$lang['contactform']['email_title'] = 'پیام از طرف سایت شما می باشد';
$lang['contactform']['been_send'] = 'پیام شما ارسال شد';
$lang['contactform']['not_send'] = 'پیام شما قادر به ارسال نمی باشد';
?>