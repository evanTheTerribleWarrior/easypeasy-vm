<?php
$lastcheck = '319';
$lastupdatestatus = 'error';
$pluck_version = '4.7.13';
?>