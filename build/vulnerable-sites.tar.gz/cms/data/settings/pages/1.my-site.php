<?php
$title = 'My Site';
$seoname = 'my-site';
$content = '';
$hidden = 'no';
?>