<?php
$sitetitle = 'My Test Site';
$email = 'admind@localhost.com';
?>